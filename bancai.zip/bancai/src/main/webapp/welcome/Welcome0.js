Ext.define("welcome.Welcome0",{
	extend:"welcome.BaseWelcome",
});