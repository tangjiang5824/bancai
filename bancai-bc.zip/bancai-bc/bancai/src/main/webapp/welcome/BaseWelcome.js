Ext.define("welcome.BaseWelcome",{
	extend:"Ext.panel.Panel",
	region : 'center',
	id : 'functionPanel',
	autoScroll: true,
	layout:'fit'
});