package com.bancai.domain;

import java.util.LinkedHashMap;

public class DataRow extends LinkedHashMap<String,Object> {
	private static final long serialVersionUID = 7445917919712339682L;

}
