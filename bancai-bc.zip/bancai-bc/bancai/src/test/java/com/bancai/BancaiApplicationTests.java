package com.bancai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancaiApplicationTests {

    @Test
    void contextLoads() {
    }

}
